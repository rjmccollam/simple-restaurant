<div class="sidebar left">
		
	<a class="logo" href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><img src="<?php $options = get_option('wedodev_theme_options'); echo $options['logo']; ?>" alt="<?php bloginfo('name'); ?>" /></a>

	<nav>
		
		<?php wp_nav_menu( array(theme_location => 'main', menu_class => 'nav')); ?> 

	</nav>

</div><!-- end sidebar -->