<?php get_header(); ?>

	<h1 class="splash right"><?php $options = get_option('wedodev_theme_options'); echo $options['title']; ?></h1>

	<h2 class="sub-splash right"><?php $options = get_option('wedodev_theme_options'); echo $options['subtitle']; ?></h2>

<?php get_footer(); ?>
