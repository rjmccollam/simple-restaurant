<?php get_header(); ?>

	<div class="content right">

		<h1>Error 404 - Page Not Found</h1>

	</div><!-- end content -->

<?php get_footer(); ?>