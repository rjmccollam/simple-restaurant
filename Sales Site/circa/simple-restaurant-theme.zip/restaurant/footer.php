	<div class="clear"></div>

</div><!-- end container -->

<div class="footer">

	<div class="container">

		<p class="left">&copy;<?php echo date("Y"); echo " "; bloginfo('name'); ?></p>		

		<p class="right">For Daily Specials Like Us On <a href="<?php $options = get_option('wedodev_theme_options'); echo $options['fb']; ?>" title="For Daily Specials Like Us On Facebook"><img src="<?php bloginfo('template_url'); ?>/images/fb.png" alt="Like Us On Facebok" /></a>.</p>

	</div><!-- end container -->

</div><!-- end footer -->

<!-- Load Scripts -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>

<script src="<?php bloginfo('template_url'); ?>/js/jquery.fsslider.min.js"></script>

<script type="text/javascript">
	$(document).ready(function() {
		$('#background').fsslider({
			spw: 5,
			sph: 4,
			delay: 6000,
			sDelay: 50,
			effect: 'rand',
			texture: 'strip1',
			navigation: false
		});
	});
</script>

<?php wp_footer(); ?>
		
</body>
</html>