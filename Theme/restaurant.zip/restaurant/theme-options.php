<?php

add_action( 'admin_init', 'theme_options_init' );
add_action( 'admin_menu', 'theme_options_add_page' );


/**
 * Init plugin options to white list our options
 */
function theme_options_init(){
	register_setting( 'wedodev_options', 'wedodev_theme_options', 'theme_options_validate' );
}

/**
 * Load up the menu page
 */
function theme_options_add_page() {
	add_theme_page( __( 'Theme Options', 'intorno' ), __( 'Theme Options', 'intorno' ), 'edit_theme_options', 'theme_options', 'theme_options_do_page' );
}

/**
 * Create the options page
 */
function theme_options_do_page() {
	global $select_options, $radio_options;

	if ( ! isset( $_REQUEST['settings-updated'] ) )
		$_REQUEST['settings-updated'] = false;

	?>
	<div class="wrap" style="width: 960px;">
		<?php screen_icon(); echo "<h2>" . get_current_theme() . __( ' Theme Options', 'intorno' ) . "</h2>"; ?>

		<?php if ( false !== $_REQUEST['settings-updated'] ) : ?>
		<div class="updated fade"><p><strong><?php _e( 'Options saved', 'intorno' ); ?></strong></p></div>
		<?php endif; ?>

		<form method="post" action="options.php">
			<?php settings_fields( 'wedodev_options' ); ?>
			<?php $options = get_option( 'wedodev_theme_options' ); ?>

			<table class="form-table">
				
				<tr>
					<td colspan="2"><h2>Home Page</h2><p>Insert your content below to populate your home page</p></td>
				</tr>
				
				<tr valign="top"><th scope="row"><?php _e( 'Logo', 'intorno' ); ?></th>
					<td>
						<input id="wedodev_theme_options[logo]" class="regular-text" type="text" name="wedodev_theme_options[logo]" value="<?php esc_attr_e( $options['logo'] ); ?>" />
						<label class="description" for="wedodev_theme_options[logo]"><?php _e( 'Insert your file URL. Logo should be 212px X 54px.', 'intorno' ); ?></label>
					</td>
				</tr>

				<tr valign="top"><th scope="row"><?php _e( 'Title', 'intorno' ); ?></th>
					<td>
						<input id="wedodev_theme_options[title]" class="regular-text" type="text" name="wedodev_theme_options[title]" value="<?php esc_attr_e( $options['title'] ); ?>" />
						<label class="description" for="wedodev_theme_options[title]"><?php _e( 'Insert your title', 'intorno' ); ?></label>
					</td>
				</tr>

				<tr valign="top"><th scope="row"><?php _e( 'Subtitle', 'intorno' ); ?></th>
					<td>
						<input id="wedodev_theme_options[subtitle]" class="regular-text" type="text" name="wedodev_theme_options[subtitle]" value="<?php esc_attr_e( $options['subtitle'] ); ?>" />
						<label class="description" for="wedodev_theme_options[subtitle]"><?php _e( 'Insert your subtitle', 'intorno' ); ?></label>
					</td>
				</tr>

				<tr>
					<td colspan="2"><h2>Slider</h2><p>Insert your image URL's for the sliding background images. These files should be high resolution for best results, but be mindful of the file size.</p></td>
				</tr>
				
				<tr valign="top"><th scope="row"><?php _e( 'Slider Image 1', 'intorno' ); ?></th>
					<td>
						<input id="wedodev_theme_options[slider-1]" class="regular-text" type="text" name="wedodev_theme_options[slider-1]" value="<?php esc_attr_e( $options['slider-1'] ); ?>" />
						<label class="description" for="wedodev_theme_options[slider-1]"><?php _e( 'Insert your image URL', 'intorno' ); ?></label>
					</td>
				</tr>

				<tr valign="top"><th scope="row"><?php _e( 'Slider Image 2', 'intorno' ); ?></th>
					<td>
						<input id="wedodev_theme_options[slider-2]" class="regular-text" type="text" name="wedodev_theme_options[slider-2]" value="<?php esc_attr_e( $options['slider-2'] ); ?>" />
						<label class="description" for="wedodev_theme_options[slider-2]"><?php _e( 'Insert your image URL', 'intorno' ); ?></label>
					</td>
				</tr>

				<tr valign="top"><th scope="row"><?php _e( 'Slider Image 3', 'intorno' ); ?></th>
					<td>
						<input id="wedodev_theme_options[slider-3]" class="regular-text" type="text" name="wedodev_theme_options[slider-3]" value="<?php esc_attr_e( $options['slider-3'] ); ?>" />
						<label class="description" for="wedodev_theme_options[slider-3]"><?php _e( 'Insert your image URL', 'intorno' ); ?></label>
					</td>
				</tr>

				<tr valign="top"><th scope="row"><?php _e( 'Slider Image 4', 'intorno' ); ?></th>
					<td>
						<input id="wedodev_theme_options[slider-4]" class="regular-text" type="text" name="wedodev_theme_options[slider-4]" value="<?php esc_attr_e( $options['slider-4'] ); ?>" />
						<label class="description" for="wedodev_theme_options[slider-4]"><?php _e( 'Insert your image URL', 'intorno' ); ?></label>
					</td>
				</tr>

				<tr>
					<td colspan="2"><h2>Social Links</h2><p>Connect your social networks</p></td>
				</tr>
				
				<tr valign="top"><th scope="row"><?php _e( 'Facebook', 'intorno' ); ?></th>
					<td>
						<input id="wedodev_theme_options[fb]" class="regular-text" type="text" name="wedodev_theme_options[fb]" value="<?php esc_attr_e( $options['fb'] ); ?>" />
						<label class="description" for="wedodev_theme_options[fb]"><?php _e( 'Insert your profile URL', 'intorno' ); ?></label>
					</td>
				</tr>

				<!-- <tr valign="top"><th scope="row"><?php _e( 'Black Box Content', 'intorno' ); ?></th>
					<td>
						<textarea id="wedodev_theme_options[bb-content]" class="large-text" cols="50" rows="5" name="wedodev_theme_options[bb-content]"><?php echo esc_textarea( $options['bb-content'] ); ?></textarea>
						<label class="description" for="wedodev_theme_options[bb-content]"><?php _e( 'Insert your content', 'intorno' ); ?></label>
					</td>
				</tr> -->
				
			</table>

			<p class="submit">
				<input type="submit" class="button-primary" value="<?php _e( 'Save Options', 'intorno' ); ?>" />
			</p>
			
		</form>
		
	</div>
	<?php
}

/**
 * Sanitize and validate input. Accepts an array, return a sanitized array.
 */
function theme_options_validate( $input ) {
	global $select_options, $radio_options;

	// Our checkbox value is either 0 or 1
	if ( ! isset( $input['option1'] ) )
		$input['option1'] = null;
	$input['option1'] = ( $input['option1'] == 1 ? 1 : 0 );
	return $input;
}

// adapted from http://planetozh.com/blog/2009/05/handling-plugins-options-in-wordpress-28-with-register_setting/