<?php
	
	// Add RSS links to <head> section
	automatic_feed_links();
	
	// Clean up the <head>
	function removeHeadLinks() {
    	remove_action('wp_head', 'rsd_link');
    	remove_action('wp_head', 'wlwmanifest_link');
    }
    add_action('init', 'removeHeadLinks');
    remove_action('wp_head', 'wp_generator');

    // Theme Options
    require_once ( get_template_directory() . '/theme-options.php' );

    // Add Read More link to excerpt
    function new_excerpt_more($more) {
        global $post;
        return '… <a class="read-more" href="'. get_permalink($post->ID) . '">' . 'Read More &raquo;' . '</a>';
    }
    add_filter('excerpt_more', 'new_excerpt_more');

    // Custom Menu
    register_nav_menu( 'main', 'Main Menu' );

?>